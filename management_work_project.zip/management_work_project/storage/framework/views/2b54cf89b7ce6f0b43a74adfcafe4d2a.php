<link rel="stylesheet" href="pages/navbarHome.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.2/font/bootstrap-icons.min.css">
<link rel="stylesheet" href="pages\fontawesome-free-6.5.1-web\css\all.min.css">
<div id="navbar">
    <ul class="navbar-left">
        <li>
            <h2 style="display: inline-block">Dira</h2>
        </li>
        <li>
            <a href="">Workspaces</a>
            <i class="bi bi-caret-down"></i>
        </li>
        <li>
            <a href="">Recently</a>
            <i class="bi bi-caret-down"></i>
        </li>
        <li>
            <a href="">Starred</a>
            <i class="bi bi-caret-down"></i>
        </li>
        <li>
            <a href="">Template</a>
            <i class="bi bi-caret-down"></i>
        </li>
        <button class="navbar-button" style="background-color: rgb(12,102,228); color: rgb(255,255,253); padding: 5px 15px; border-radius: 3px; border: none; cursor: pointer">News</button>
    </ul>

    <div class="navbar-right">
        <div class="search-input">
            <i class="bi bi-search"></i>
            <input type="text" name="" id="" placeholder="Search">
        </div>

        <div class="information-icon">
            <span>
                <i class="bi bi-bell notificate-icon">
                    
                <i class="bi bi-dot signal-icon"></i>

                </i>
            </span>
            <span>
                <i class="bi bi-question-circle"></i>
            </span>
            <span>
                <img src="" alt="" srcset="">
            </span>

            <div class="information-notificate">
            <?php if(isset($notification_user)): ?>
        
            <?php $__currentLoopData = $notification_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $decodedNotifications = json_decode($notification, true);
            ?>
                <div class="element-notificate">
                    <p class="name-sender"><?php echo e($decodedNotifications['data'][0]); ?> đã thêm</p>
                    <img src="https://www.vietnamworks.com/hrinsider/wp-content/uploads/2023/12/anh-den-ngau.jpeg" alt="" srcset="">
                    <p class="message-sender"><?php echo e($decodedNotifications['data'][1]); ?> vào nhóm <?php echo e($decodedNotifications['data'][2]); ?></p>
                </div> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
</div>

            
        </div>

        <div class="avatar open-subnav-btn">
            <img class="avtimg" src="<?php echo e(Auth::user()->avatar); ?>" alt="avt" >
            <i class="fa-solid fa-chevron-down fa-xs" style="color: #ffffff;"></i>
            <ul class="subnav hide">
                <li><a href="#"><i class="fa-solid fa-gear"></i>Setting</a></li>
                <li><a href="<?php echo e(route('profile')); ?>"><i class="fa-solid fa-id-badge"></i>Profile</a></li>
                <li><a href="#"><i class="fa-solid fa-info"></i>About</a></li>
                <li><a href="<?php echo e(route('logout')); ?>"><i class="fa-solid fa-arrow-right-from-bracket"></i>Logout</a></li>
                </ul>
        </div>

        
    </div>
</div>
<script src="pages/subnav.js"></script>
<script type="module">
    let signal_icon = document.querySelector(".navbar-right .information-icon .signal-icon");
    let information_notificate = document.querySelector(".navbar-right .information-icon .information-notificate");
    let notificate_icon = document.querySelector(".navbar-right .information-icon .notificate-icon");
    let element_notificate = document.querySelector(".navbar-right .information-icon .information-notificate .element-notificate");

    import '<?php echo e(mix('resources/js/app.js')); ?>';
    window.Echo.private(`AddPeopleOnTeam.<?php echo e(session('id_user')); ?>`)
    .listen('AddPeople', (e) => {
        console.log(e);
        signal_icon.style.display = 'block';

        let element_notificate = document.createElement('div');
        element_notificate.classList.add('element-notificate');

        let name_sender = document.createElement('p');
        name_sender.classList.add('name-sender');
        name_sender.innerText = e.data[0];

        let img_sender = document.createElement('img');
        img_sender.src = "https://www.vietnamworks.com/hrinsider/wp-content/uploads/2023/12/anh-den-ngau.jpeg";

        let message_sender = document.createElement('p');
        message_sender.classList.add('message-sender');
        message_sender.innerText = e.data[0] + " " + "đã mời bạn vào nhóm";

        element_notificate.appendChild(name_sender);
        element_notificate.appendChild(img_sender);
        element_notificate.appendChild(message_sender);
        information_notificate.appendChild(element_notificate);

        });

        notificate_icon.addEventListener('click', function() {
            element_notificate.style.display = (element_notificate.style.display === 'block') ? 'none' : 'block';
 });  
</script>



<?php /**PATH C:\xampp\htdocs\unitop-laravel\Dira\DIRA\management_work_project\resources\views/layouts/header.blade.php ENDPATH**/ ?>