<div class="workspace-title">
    <h2>Workspaces</h2>
    <img src="pages/image/plus.png" alt="">
</div>
<div class="workspace-container">
    <?php if(isset($workspaces)): ?>
    <?php $__currentLoopData = $workspaces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workspace): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="item" id="<?php echo e($workspace->id); ?>" title="<?php echo e($workspace->name); ?>">
        <img class="square" src="<?php echo e($workspace->avatar); ?>">
        <h3><?php echo e($workspace->name); ?></h3>
        <img class="arrow" src="pages/image/arrow_down.png" alt="">
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <!-- <div class="item">
        <img class="square" src="pages/image/Rectangle.png">
        <h3>Workspace name</h3>
        <img class="arrow" src="pages/image/arrow_down.png" alt="">
    </div>
    <div class="item">
        <img class="square" src="pages/image/Rectangle.png">
        <h3>Workspace name</h3>
        <img class="arrow" src="pages/image/arrow_down.png" alt="">
    </div> -->
</div><?php /**PATH C:\xampp\htdocs\unitop-laravel\Dira\DIRA\management_work_project\resources\views/sidebar/folder.blade.php ENDPATH**/ ?>